package com.example.examentema3alvaro;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);



//        actividad1();
        actividad2();
//         actividad3();

    }
    public void actividad1(){
        setContentView(R.layout.layout1);
        final Button btnAcceder = findViewById(R.id.btnAcceder);
        final EditText etNombre = findViewById(R.id.etNombre);
        final EditText etContraseña = findViewById(R.id.etContraseña);

        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                etNombre.setVisibility(View.VISIBLE);
                etContraseña.setVisibility(View.VISIBLE);
                btnAcceder.setVisibility(View.VISIBLE);
            }
        }, 3000);

        btnAcceder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nombre = etNombre.getText().toString();
                String contraseña = etContraseña.getText().toString();

                if(nombre.equals("") || contraseña.equals("")){

                    Toast.makeText(MainActivity.this,"Error! Introduzca el usuario y la clave",Toast.LENGTH_SHORT).show();

                }else if(nombre.equals("") && contraseña.equals("")){
                    Toast.makeText(MainActivity.this,"Error! Introduzca el usuario y la clave",Toast.LENGTH_SHORT).show();

                }else{
                    Toast.makeText(MainActivity.this,"Hola " + nombre + ". Accediendo a la app",Toast.LENGTH_SHORT).show();

                }
            }
        });

        }

        public void actividad2(){
            setContentView(R.layout.layout2);

            int botonSeleccionado = 0;

            final Button btn1 = findViewById(R.id.boton1);
            final Button btn2 = findViewById(R.id.boton2);
            final Button btn3 = findViewById(R.id.boton3);
            final Button btnSiguiente = findViewById(R.id.btnSiguiente);

            btn1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    btn1.setBackgroundColor(getResources().getColor(R.color.white));
                    btn1.setTextColor(getResources().getColor(R.color.black));
                    btn2.setBackgroundColor(getResources().getColor(R.color.black));
                    btn2.setTextColor(getResources().getColor(R.color.white));
                    btn3.setBackgroundColor(getResources().getColor(R.color.black));
                    btn3.setTextColor(getResources().getColor(R.color.white));

                }
            });
            btn2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    btn1.setBackgroundColor(getResources().getColor(R.color.black));
                    btn1.setTextColor(getResources().getColor(R.color.white));
                    btn2.setBackgroundColor(getResources().getColor(R.color.white));
                    btn2.setTextColor(getResources().getColor(R.color.black));
                    btn3.setBackgroundColor(getResources().getColor(R.color.black));
                    btn3.setTextColor(getResources().getColor(R.color.white));

                }
            });
            btn3.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    btn1.setBackgroundColor(getResources().getColor(R.color.black));
                    btn1.setTextColor(getResources().getColor(R.color.white));
                    btn2.setBackgroundColor(getResources().getColor(R.color.black));
                    btn2.setTextColor(getResources().getColor(R.color.white));

                    btn3.setBackgroundColor(getResources().getColor(R.color.white));
                    btn3.setTextColor(getResources().getColor(R.color.black));
                }
            });

            btnSiguiente.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Toast.makeText(MainActivity.this,"Accediendo a la siguiente plantilla",Toast.LENGTH_SHORT).show();
                }
            });

        }

        public void actividad3(){
            setContentView(R.layout.layout3);

            setContentView(R.layout.layout3);
            Spinner spinner = (Spinner) findViewById(R.id.spinner);
            String[] valores = {"1 dia", "2 dias", "3 dias", "4 dias", "5 dias", "6 dias", "7 dias"};

            spinner.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item,valores));
            final TextView texto = findViewById(R.id.tvSpinner);
            String valor = spinner.getSelectedItem().toString();
            texto.setText(valor);

            spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> adaptador, View view, int position, long id) {
                    String cadena = (String) adaptador.getItemAtPosition(position);
                    texto.setText(cadena);
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {

                }
            });

        }
}